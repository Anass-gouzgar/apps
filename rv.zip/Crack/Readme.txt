Open command prompt as administrator on this folder and run 'install.bat'.

*** Do NOT copy contents of this folder to the installation folder and run from there. ***

WWW.DOWNLOADLY.IR