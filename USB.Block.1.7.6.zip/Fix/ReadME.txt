
1. Install "USB Block" and do not Run.

2. Run "Block.bat"

or Add these lines to: C:\Windows\System32\drivers\etc\hosts
     
127.0.0.1 www.newsoftwares.net
127.0.0.1 www.password-protect-folders.net

or use Firewall!
     

3. Register the app using kEy.txt